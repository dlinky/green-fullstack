
public class TestEx01 {

	public static void main(String[] args) {
		System.out.print("Hello World !!!");

	}

}
